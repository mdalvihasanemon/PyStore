from datetime import datetime

now = datetime.now()
print(f"Current Date and Time: {now}")
