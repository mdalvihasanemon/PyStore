fruits = ["apple", "banana", "cherry"]
fruits.append("orange")
print(f"Fruits: {fruits}")

for fruit in fruits:
    print(fruit)
