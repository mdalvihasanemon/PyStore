import random

random_number = random.randint(1, 100)
print(f"Random Number: {random_number}")
