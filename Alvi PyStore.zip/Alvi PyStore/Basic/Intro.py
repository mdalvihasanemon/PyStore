#First code  of our learning stage
print("Hello, World!")
print("Hello Everyone from ALVI Pystore")

