##For loop

for i in range(1, 6):
    print(f"Number: {i}")

##while loop
count = 5
while count > 0:
    print(f"Countdown: {count}")
    count -= 1
