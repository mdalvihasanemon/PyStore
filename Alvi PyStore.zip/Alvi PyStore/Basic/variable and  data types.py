#basic types for the various types of parameter values. 
a = 10 # Integer
b = 3.14 # Float
c = "Python" # String
d = True # Boolean
print(f"Integer: {a}, Float: {b}, String: {c}, Boolean: {d}")
