import math

radius = 5
area = math.pi * radius ** 2
print(f"Area of the circle: {area}")
