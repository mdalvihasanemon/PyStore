square = lambda x: x ** 2
print(f"Square of 5: {square(5)}")
