text = " Hello, World! "
print(text.strip())
print(text.lower())
print(text.upper())
print(text.replace("World", "PyStore"))
