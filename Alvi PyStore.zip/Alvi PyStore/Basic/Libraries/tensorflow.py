import tensorflow as tf

a = tf.constant(5)
b = tf.constant(3)
c = a + b

print(f"Result: {c}")
