person = {"name": "Alvi", "age": 22, "city": "Bangladesh"}
print(f"Name: {person['name']}")

person["job"] = "Engineer"
print(f"Updated Dictionary: {person}")
